/*
 * lab61.c
 *
 *  Created on: Dec 5, 2015
 *      Author: kornaros
 */


#include "xparameters.h"
#include "xgpio.h"
//#include "led_ip.h"
// Include scutimer header file
#include "xscutimer.h"
#include "xil_cache.h"
//====================================================
XScuTimer Timer;		/* Cortex A9 SCU Private Timer Instance */

#define ONE_TENTH 32500000 // half of the CPU clock speed/10

int main (void)
{

	Xil_ICacheDisable();
	Xil_DCacheDisable();

   XGpio dip, push, leds;
   int psb_check, dip_check, dip_check_prev, count, Status, i;
   int *shared_sum;

   // PS Timer related definitions
 //  XScuTimer_Config *ConfigPtr;
 //  XScuTimer *TimerInstancePtr = &Timer;

   while(1){
	   if(count==0){
		   XGpio_DiscreteWrite(&leds, 1, 128);
		   sleep(1);
		   count=1;
	   }else if(count!=0){
		   XGpio_DiscreteWrite(&leds, 1, 0);
		   sleep(1);
		   count=0;
	   }

	   for(i=0;i<10;i++){
		   printf("sum %d", *shared_sum);
	   }
   }


   xil_printf("-- A1: hello ! --\r\n");
   unsigned int *shared_v = 0x11000000;
   *shared_v = 0;

   return ;
}
